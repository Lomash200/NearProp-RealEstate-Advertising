create function set_permanent_id() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.permanent_id IS NULL THEN
        NEW.permanent_id := generate_nearprop_id();
    END IF;
    RETURN NEW;
END;
$$;

alter function set_permanent_id() owner to postgres;

grant execute on function set_permanent_id() to nearprop_user;

