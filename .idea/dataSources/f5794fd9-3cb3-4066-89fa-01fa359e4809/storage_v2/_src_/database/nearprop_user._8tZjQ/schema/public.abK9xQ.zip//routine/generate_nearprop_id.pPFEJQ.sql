create function generate_nearprop_id() returns text
    language plpgsql
as
$$
DECLARE
    date_part TEXT;
    time_part TEXT;
    random_suffix TEXT;
    complete_id TEXT;
    counter INT;
BEGIN
    -- Create date part in YYYYMMDD format
    date_part := TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDD');
    
    -- Create time part with milliseconds
    time_part := TO_CHAR(CURRENT_TIMESTAMP, 'HH24MISSMS');
    
    -- Add random 3-digit suffix to ensure uniqueness even with multiple creations in the same millisecond
    random_suffix := LPAD(FLOOR(RANDOM() * 1000)::TEXT, 3, '0');
    
    -- Combine parts (RNPU prefix + YYYYMMDD date + TTTT time in ms + random suffix)
    complete_id := 'RNPU' || date_part || SUBSTRING(time_part, 1, 4) || random_suffix;
    
    RETURN complete_id;
END;
$$;

alter function generate_nearprop_id() owner to postgres;

grant execute on function generate_nearprop_id() to nearprop_user;

